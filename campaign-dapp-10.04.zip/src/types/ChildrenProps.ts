export interface ChildrenProps {
  children: React.ReactNode | React.ReactNode[];
}
