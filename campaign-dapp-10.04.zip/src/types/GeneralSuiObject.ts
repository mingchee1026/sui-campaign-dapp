export interface GeneralSuiObject {
    objectId: string;
    packageId: string;
    moduleName: string;
    structName: string;
    version: string;
}